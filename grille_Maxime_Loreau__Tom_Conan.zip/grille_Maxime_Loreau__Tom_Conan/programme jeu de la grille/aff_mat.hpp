#include "struct.hpp"

void affichage_mat_nb(mat_nb grille,int n);
void affichage_mat_sl(mat_sl grille,int n);