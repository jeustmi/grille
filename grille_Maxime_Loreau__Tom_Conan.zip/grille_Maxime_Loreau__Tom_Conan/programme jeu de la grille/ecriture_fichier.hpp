#include <string>

#include "struct.hpp"

using fof=std::ofstream;
using ch=std::string;

void écriture_fichier_solution(grille_complete grille, ch fic);