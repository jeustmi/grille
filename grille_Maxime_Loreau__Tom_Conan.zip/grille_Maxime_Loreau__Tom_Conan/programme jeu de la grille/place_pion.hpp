#include "struct.hpp"

void init_sl(grille_complete & grille);

void placePionRouge(grille_complete & grille, int & dn);
void place_noir(grille_complete & grille, int & dp);
void place_vert(grille_complete & grille);
void place_orange(grille_complete & grille, int & dn);
void place_bleu(grille_complete & grille, int & dn);
void place_jaune(grille_complete & grille);
void place_zero(grille_complete & grille);