#include "struct.hpp"

void compte_jeton(grille_complete &grille);