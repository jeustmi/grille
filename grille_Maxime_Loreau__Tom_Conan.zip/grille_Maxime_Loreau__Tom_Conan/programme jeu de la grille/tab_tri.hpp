#include "struct.hpp"

void init_tab_tri(grille_complete & grille);
void affiche_tab_tri(grille_complete grille);
void tri_selection(grille_complete & grille);